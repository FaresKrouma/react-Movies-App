import React, { useState } from "react";
import Header from "./components/Header/Header";
import NavBar from "./components/NavBar";
import styled from "styled-components";
import { BrowserRouter, Route } from "react-router-dom";
import Trending from "./components/Trending";
import Movies from "./components/Movies";
import Series from "./components/Series";
import Search from "./components/Search";

function App() {
   const [trendingType, setTrendingType] = useState("all");
   const [moviesSortType, setMoviesSortType] = useState("popularity.desc");
   const [seriesSortType, setSeriesSortType] = useState("popularity.desc");

   return (
      <BrowserRouter>
         <DivElement>
            <Header />
            <Route
               path="/"
               exact
               component={() => {
                  return <Trending trendingType={trendingType} />;
               }}
            />

            <Route
               path="/movies"
               component={() => {
                  return <Movies moviesSortType={moviesSortType} />;
               }}
            />
            <Route
               path="/tv-series"
               component={() => {
                  return <Series seriesSortType={seriesSortType} />;
               }}
            />
            <Route path="/search" component={Search} />
            <NavBar
               setTrendingType={setTrendingType}
               setMoviesSortType={setMoviesSortType}
               setSeriesSortType={setSeriesSortType}
            />
         </DivElement>
      </BrowserRouter>
   );
}

export default App;

const DivElement = styled.div``;
