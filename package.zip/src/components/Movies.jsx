import React, { useState, useEffect } from "react";
import MovieCard from "./MovieCard";
import styled from "styled-components";
import { VscLoading } from "react-icons/vsc";
import Pagination from "./Pagination";
import Genres from "./Genres";

const Series = () => {
   const APIKEY = "95f8742efabd7ac4a603dea27f261aec";

   const [moviesArray, setMoviesArray] = useState([]);
   const [isLoaded, setIsLoaded] = useState(false);
   const [currentPage, setCurrentPage] = useState(1);
   const [totalPages, setTotalPages] = useState();
   const [selectedGenres, setSelectedGenres] = useState([]);

   useEffect(() => {
      fetch(
         `https://api.themoviedb.org/3/discover/movie?api_key=95f8742efabd7ac4a603dea27f261aec&include_video=true&include_adult=true&language=en-US&sort_by=popularity.desc&timezone=America%2FNew_York&with_watch_monetization_types=flatrate&page=${currentPage}&with_genres=${selectedGenres.join(
            ","
         )}`
      )
         .then((resp) => resp.json())
         .then((respData) => {
            setMoviesArray(respData.results);
            setIsLoaded(true);
            setTotalPages(respData.total_pages);
            console.log(respData.results);
         });
   }, [currentPage, selectedGenres]);
   return (
      <>
         <DivElement>
            <p className="title">🎥 Movies</p>
            <Genres
               type="movie"
               selectedGenres={selectedGenres}
               setSelectedGenres={setSelectedGenres}
               setCurrentPage={setCurrentPage}
            />
            {!isLoaded ? (
               <h1 className="loading">
                  <VscLoading className="animation" />
                  Loading..
               </h1>
            ) : (
               <>
                  <div className="movies-container">
                     {moviesArray.map((element) => {
                        return <MovieCard key={element.id} data={element} />;
                     })}
                  </div>
                  <Pagination
                     currentPage={currentPage}
                     totalPages={totalPages}
                     setCurrentPage={setCurrentPage}
                  />
               </>
            )}
         </DivElement>
      </>
   );
};

export default Series;

const DivElement = styled.div`
   display: flex;
   margin: 4rem 5rem;
   justify-content: center;
   align-items: center;
   flex-direction: column;
   /* flex-wrap: wrap; */
   .loading {
      margin-top: 13rem;
      color: #eee;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      font-size: 5rem;
      .animation {
         animation: rotate 1.5s linear infinite;
      }
   }

   .title {
      color: white;
      font-weight: 100;
      letter-spacing: 1px;
      text-shadow: 4px 4px rgba(0, 0, 0, 0.4);
      line-height: 1;
      font-size: 2.2rem;
      margin: 1rem 0;
   }

   .movies-container {
      animation: scale 0.5s;
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      align-items: center;
   }

   @media (max-width: 1140px) {
      margin: 4rem 1rem;
   }
   @keyframes rotate {
      0% {
         transform: rotate(0deg);
      }
      100% {
         transform: rotate(360deg);
      }
   }
`;
