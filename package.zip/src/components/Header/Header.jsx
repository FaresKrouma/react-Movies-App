import React from "react";
import styled from "styled-components";
import headerImage from "./animal-kingdom.png";

const Header = () => {
   return (
      <DivElement className="header">
         <h1>
            Movie<span>Gator </span>
         </h1>
         <h2> Entertainment</h2>
         <img src={headerImage} alt="aligator image" />
      </DivElement>
   );
};

export default Header;

const DivElement = styled.header`
   display: flex;
   justify-content: center;
   box-shadow: 0 2px 3px 1px rgba(0, 0, 0, 0.4);
   letter-spacing: 1px;
   position: fixed;
   top: 0;
   width: 100%;
   z-index: 100;
   background: #2525258a;
   font-size: 1.3rem;
   span {
      color: crimson;
      padding-left: 0.2rem;
   }
   h2 {
      color: #ddd;
      padding: 0.5rem;
   }
   img {
      height: 45px;
      width: 45px;
      margin: 0 0.3rem;
      align-self: center;
   }
   @media (max-width: 600px) {
      font-size: 1.1rem;
      img {
         height: 35px;
         width: 35px;
      }
   }
`;
