import React, { useEffect, useState } from "react";
import styled from "styled-components";

const Modal = ({ id, type }) => {
   const [movieData, setMovieData] = useState();

   useEffect(() => {
      fetch(
         `https://api.themoviedb.org/3/${type}/${id}?api_key=95f8742efabd7ac4a603dea27f261aec&language=en-US`
      )
         .then((resp) => resp.json())
         .then((respData) => console.log(respData));
   }, []);
   return (
      <DivElement>
         <h1>im a modal</h1>
      </DivElement>
   );
};

export default Modal;

const DivElement = styled.div`
   position: absolute;
   left: 0;
   color: white;

   z-index: 102;
   height: 100%;
   width: 100%;
   background-color: rgba(0, 0, 0, 0.5);
   font-size: 10rem;
`;
