import React, { useState, useEffect } from "react";
import MovieCard from "./MovieCard";
import styled from "styled-components";
import { VscLoading } from "react-icons/vsc";
import Pagination from "./Pagination";
import Genres from "./Genres";
import Modal from "./Modal";

const Series = () => {
   const APIKEY = "95f8742efabd7ac4a603dea27f261aec";

   const [moviesArray, setMoviesArray] = useState([]);
   const [isLoaded, setIsLoaded] = useState(false);
   const [currentPage, setCurrentPage] = useState(1);
   const [totalPages, setTotalPages] = useState();
   const [selectedGenres, setSelectedGenres] = useState([]);
   const [showModal, setShowModal] = useState(false);

   const handleShowModal = () => setShowModal(true);

   useEffect(() => {
      fetch(
         `https://api.themoviedb.org/3/discover/tv?api_key=95f8742efabd7ac4a603dea27f261aec&language=en-US&sort_by=popularity.desc&timezone=America%2FNew_York&with_watch_monetization_types=flatrate&page=${currentPage}&with_genres=${selectedGenres.join(
            ","
         )}`
      )
         .then((resp) => resp.json())
         .then((respData) => {
            setMoviesArray(respData.results);
            setIsLoaded(true);
            setTotalPages(respData.total_pages);

            console.log(respData.results);
         });
   }, [currentPage, selectedGenres]);
   return (
      <>
         <DivElement>
            <p className="title">📺 TV Series</p>
            <Genres
               type="tv"
               selectedGenres={selectedGenres}
               setSelectedGenres={setSelectedGenres}
               setCurrentPage={setCurrentPage}
            />

            {!isLoaded ? (
               <h1 className="loading">
                  <VscLoading className="animation" />
                  Loading..
               </h1>
            ) : (
               <>
                  <div className="movies-container">
                     {moviesArray.map((element, index) => {
                        return <MovieCard key={index} data={element} />;
                     })}
                  </div>

                  <Pagination
                     currentPage={currentPage}
                     totalPages={totalPages}
                     setCurrentPage={setCurrentPage}
                  />
               </>
            )}
         </DivElement>
      </>
   );
};

export default Series;

const DivElement = styled.div`
   display: flex;
   margin: 4rem 5rem;
   justify-content: center;
   align-items: center;
   flex-direction: column;
   /* position: relative; */
   /* flex-wrap: wrap; */
   .loading {
      margin-top: 13rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      color: #eee;
      font-size: 5rem;
      .animation {
         animation: rotate 1.5s linear infinite;
      }
   }

   .title {
      color: white;
      font-weight: 100;
      letter-spacing: 1px;
      line-height: 1;
      text-shadow: 4px 4px rgba(0, 0, 0, 0.4);
      font-size: 2.2rem;
      margin: 1rem 0;
   }

   .movies-container {
      animation: scale 0.5s;
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      align-items: center;
   }

   @media (max-width: 1140px) {
      margin: 4rem 1rem;
   }
   @keyframes rotate {
      0% {
         transform: rotate(0deg);
      }
      100% {
         transform: rotate(360deg);
      }
   }
`;
